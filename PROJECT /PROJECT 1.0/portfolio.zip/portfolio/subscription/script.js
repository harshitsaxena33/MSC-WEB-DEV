const subscribeForm = document.getElementById('subscribeForm');
const emailInput = document.getElementById('emailInput');
const subscriptionStatus = document.getElementById('subscriptionStatus');

subscribeForm.addEventListener('submit', function (e) {
  e.preventDefault();
  const email = emailInput.value;

  // Simulate subscription request (you might use AJAX or fetch to send data to your backend)
  setTimeout(function() {
    subscriptionStatus.textContent = `Subscribed successfully with email: ${email}`;
  }, 1000);

  emailInput.value = ''; // Clear input after submission
});
